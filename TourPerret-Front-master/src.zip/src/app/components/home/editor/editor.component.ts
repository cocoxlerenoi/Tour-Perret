import { Component } from '@angular/core';

@Component({
    selector: 'my-editor',
    templateUrl: 'editor.component.html',
    styleUrls: ['./editor.component.scss']
})

export class EditorComponent {

    constructor() {
    }
}
