import { Component } from '@angular/core';

@Component({
    selector: 'my-account',
    templateUrl: 'account.component.html',
    styleUrls: ['account.component.scss']
})

export class AccountComponent {

    constructor() { }
}
