export interface HttpResponse {

    status: string;
    code: number;
    data: any;
    message: string;
}