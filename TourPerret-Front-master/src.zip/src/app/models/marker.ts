export class Marker {

    constructor(public time: number, public name: string) {
    }
}


